const mongoose = require('mongoose');
const { Schema } = mongoose;
const bcrypt = require('bcryptjs');

//campos de un usuario
const TrainingSchema = new Schema({

    date: {type: Date, required: true},
    hours: {type: Number, required: true}, 
    energy_level: {type: Number, required: true}, 
    mood_before: {type: Number, required: true}, 
    mood_after: {type: Number, required: true}, 
    concentration_before: {type: Number, required: true}, 
    concentration_after: {type: Number, required: true},
    file: {type: Array}

   })


module.exports = mongoose.model('Training', TrainingSchema);