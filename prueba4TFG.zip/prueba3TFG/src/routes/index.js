//urls de la aplicacion principal

const router = require('express').Router(); //facilita la creacion de routers.
const Training = require('../models/Training');

router.get('/', (req,res) => {
    //res.send('Index');
    res.render('index');
});

router.get('/about', (req,res) => {
    //res.send('About');
    res.render('about');
});

router.get('/panel', async function(req,res) {
    //res.send('About');
    const folder = await Training.find().sort({'date': 1});
    res.render('panel', {folder:folder});
});

router.get('/formulario_entreno', (req,res) => {
    //res.send('Formulario');
    res.render('formulario_entreno');
});

router.get('/formulario_descanso', (req,res) => {
    //res.send('Formulario');
    res.render('formulario_descanso');
});



module.exports = router;