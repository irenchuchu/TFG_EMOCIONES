const express = require('express');
const path = require ('path');
const exphbs = require('express-handlebars');
const _handlebars = require('handlebars');
const methodOverride = require('method-override');
const session = require('express-session');
const flash = require('connect-flash');
const passport = require('passport');
const multer = require('multer');
const Training = require('./models/Training');
//const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access');
/*
express.engine('handlebars', exphbs({
    handlebars: allowInsecurePrototypeAccess(_handlebars)
}))
*/

//const d3 = require('d3');
/*
require.config({
    paths: {
        d3: "https://d3js.org/d3.v5.min"
     }
});

require(["d3"], function(d3) {
    window.d3 = d3;
}); */

// INICIALIZACIONES
const app = express();
require('./database');
require('./config/passport');

// SETTINGS -> Configuraciones
app.set('port', process.env.PORT || 3000); //definimos el puerto, si existe uno que lo tome y sino que use el 3000
app.set('views', path.join(__dirname, 'views')); // join -> concatena carpetas. Localizamos carpeta views, que es donde irán los HTMLs
app.engine('.hbs', exphbs({ //.hbs para que sean archivos handlebars
    //propiedades para saber usar las vistas:
     defaultLayout: 'main', //navegación que se repetirá en todas las vistas
     layoutsDir: path.join(app.get('views'), 'layouts'), 
     partialsDir: path.join(app.get('views'), 'partials') ,
     extname:'.hbs' //extension de los archivos
 }));
 app.set('view engine', '.hbs'); //utilizar la configuración / motor de las vistas 


// MIDDLEWARES -> Funciones ejecutadas antes de llegar al servidor
app.use(express.urlencoded({extended: false})); //para recibir datos del usuario (email,contraseña)
app.use(methodOverride('_method')); //para que los formularios pueden usar otros metodos ademas de GET y POST 
app.use(session({ //para autenticar el usuario
    secret: 'mysecretapp',
    resave: true,
    saveUninitialized: true
}));

app.use(passport.initialize());
app.use(passport.session());
app.use(flash());


// VARIABLES GLOBALES -> Colocar ciertos datos accesibles por toda la aplicacion
app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    res.locals.user = req.user || null;
    next();
});

//SUBIDAS DE ARCHIVOS con MULTER

const storage = multer.diskStorage({
    destination: 'src/uploads/',
    filename: function(req, file, cb){
        cb("",req.user.email + Date.now() + file.originalname);
    }
})

const upload = multer({
    storage: storage
});


// FORMULARIO SIN EJERCICIO:

const storage2 = multer.diskStorage({
    destination: 'src/uploads2/',
    filename: function(req, file, cb){
        cb("",req.user.email + Date.now() + file.originalname);
    }
})

const upload2 = multer({
    storage: storage2
});

//Todo: ELIMINAR ESTO CUANDO HAGAS EL DE DESCANSO!!!!!!!!!!!!!!!!!!!!!!!
app.post("/files2",upload2.array('avatar2', 12), (req,res) => { 
    res.send("TODO BIEN");
    //res.render("./panel");
    
}); 


//GESTION DEL FORMULARIO:

//Todo: 
app.post("/training", upload.array('file', 12), async function(req,res, next){
    const {date, 
        hours, 
        energy_level, 
        mood_before, 
        mood_after, 
        concentration_before, 
        concentration_after} = req.body;
    
    const errors = [];
    if(!date){
        errors.push({text: 'Inserte la fecha en el formulario'});

    }

    if(errors.length > 0){
        res.render('/formulario_entreno', {errors});
    }
    else{
        /* const addTraining = new Training({
            date: date,
            hours: hours,
            energy_level: energy_level,
            mood_before: mood_before,
            mood_after: mood_after,
            concentration_before: concentration_before,
            concentration_after: concentration_after 
        });*/

        const addTraining = new Training({
            hours, 
            energy_level, 
            mood_before, 
            mood_after, 
            concentration_before, 
            concentration_after
        });

        if(date){
            addTraining.date = date;
            //Todo: cambiar formato a la fecha para q coja los 10 primeros caracteres SPLICE o SLICES o algo asi
        }

        if(req.files){
            for(let i = 0; i < req.files.length; i++){
                addTraining.file[i] = req.files[i];
            }
        }
        
        await addTraining.save();
        
        const allTrainings = await Training.find().sort({'date': 1}); //para ordenar

        res.render('panel', {folder: allTrainings});
    }


});


// RUTAS -> urls
app.use(require('./routes/index'));
app.use(require('./routes/users'));


// ARCHIVOS ESTATICOS
app.use(express.static(path.join(__dirname, 'public')));


// INICIAR SERVIDOR 

app.listen(app.get('port'), () => {
    console.log('El servidor esta escuchando en el puerto', app.get('port')) //LEYENDO PUERTO
});

/*
let filename = 'uploads';

d3.csv(filename).then(function(loadedData){

console.log(loadedData);

}); */